# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class AuktionenItem(scrapy.Item):

    images = scrapy.Field()
    id = scrapy.Field()
    heading = scrapy.Field()
    lot_number = scrapy.Field()
    number = scrapy.Field()
    auction_number = scrapy.Field()
    condition = scrapy.Field()
    solf_for = scrapy.Field()
    estimate = scrapy.Field()
    description = scrapy.Field()
    url = scrapy.Field()
      
    pass
