# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.pipelines.images import ImagesPipeline
import scrapy
import sqlite3

class AuktionenImagePipeline(ImagesPipeline):
    def get_media_requests(self, item, info):       
        count = 0
        if not item['images'] == 'None':
            for img_url in item['images']:
                count += 1
                yield scrapy.Request(img_url, meta={'image_name': item["id"],'count': count})

    def file_path(self, request, response=None, info=None):
        return f"{request.meta['image_name']}'_{request.meta['count']}'.jpg" 

class AuktionenPipeline(object):

    def __init__(self,new):

        self.create_connection()
        self.create_table(new)
        pass

    @classmethod
    def from_crawler(cls, crawler):
        return cls(new=crawler.spider.new)


    def create_connection(self):

        self.conn = sqlite3.Connection('auktionen.db')
        self.curr = self.conn.cursor()
    
    def create_table(self,new):

        if new == "yes":

            self.curr.execute("drop table if exists auktionen_table")
            self.curr.execute("CREATE TABLE auktionen_table( id text,url text,product_images text,heading text,lot_number text,number text,auction_number text,condition text,solf_for text,estimate text,description text)")

    def process_item(self, item, spider):

        self.store_db(item)

        return item

    def store_db(self,item):

        product_images = ",".join(item["images"])

        self.curr.execute(f"insert into auktionen_table values ('{item['id']}','{item['url']}','{product_images}','{item['heading']}','{item['lot_number']}','{item['number']}','{item['auction_number']}','{item['condition']}','{item['solf_for']}','{item['estimate']}','{item['description']}')")

        self.conn.commit()