from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor

from ..items import AuktionenItem
import re
import json
from bs4 import BeautifulSoup 

import time

from selenium import webdriver

class AuktionenSpider(CrawlSpider):

    name = "auktionen"

    id = 0

    main_link = "https://www.auktionen-gaertner.de"

    start_urls = ['https://www.auktionen-gaertner.de/?FTSearchHTML|Name=DetailsA&Cat=GP&UID=EC19F9D05BE954DBC125797200522C21&Phase=AUCTION&Lang=DE&DetailDB=PHILNET/GAERTNER/GPKATAUK21&CID=1&SessionID=uF7EHYw5PJfkm5SiJyX1']

    html = None

    def __init__(self, new, *args, **kwargs):                    
        super(AuktionenSpider, self).__init__(*args, **kwargs) 

        self.new = new

        if new == "no":
            id_file = open("id.txt","r")
            self.id = id_file.readline()
            self.id = self.id.strip("\n")

            self.id = int(self.id)
            id_file.close()

        file = open("input.txt","r")

        links = []

        for catg in file.readlines():
            links.append(catg)

        file.close()

        self._url_list = links


    def start_requests(self):

        for links in self._url_list:

            driver = webdriver.Chrome()
            driver.get(links)

            while True:
                page = driver.find_elements_by_css_selector('#AID_PageSelect:last-child')     

                soup = BeautifulSoup(driver.page_source)

                for a in soup.find_all('a', href=lambda href: href and "/?FTSearchHTML|" in href):
                        yield Request(url=f"https://www.auktionen-gaertner.de{a['href']}",callback=self.product_page)

                time.sleep(2)

                if page:
                    page[0].click()
                else:
                    break
            driver.close()

    def product_page(self,response):

        product = AuktionenItem()

        id_file = open("id.txt","w")
        id_file.write(str(self.id))
        id_file.close()

        product["id"] = self.id

        product["url"] = response.url

        self.id += 1
        

        main_link = re.findall("var PicServer=(.+?);\n", response.body.decode("utf-8"), re.S)
        img_links = re.findall("var Path=(.+?);\n", response.body.decode("utf-8"), re.S)
        imgs = re.findall("var ImagesList=(.+?);\n", response.body.decode("utf-8"), re.S)

        try:
            imgs = imgs[0].split(",")
        except:
            pass
        
        product["images"] = []

        for index,img in enumerate(imgs):
            product["images"].append(main_link[0] + img_links[0] + img)
            product["images"][index] = product["images"][index].replace('"',"")

        product["heading"] = "None"
        product["heading"] = response.css(".FTHeadline::text").extract_first()

        if product["heading"]:
            product["heading"] = " ".join(product["heading"])
            product["heading"] = product["heading"].replace("'","")

        product["lot_number"] = "None"
        product["lot_number"] = response.css(".TextB3::text").extract_first()

        product["number"] = "None"
        product["number"] =  response.css('td:nth-child(4) .TextB3::text').extract_first()
        
        product["auction_number"] = "None"
        product["auction_number"] = response.css('#CID_RT_InAuktNr0 ~ font::text').extract_first()

        main_conds = response.css(".TextB3 img::attr(src)").extract()

        if main_conds:
            product["condition"] = 0

            for main_cond in main_conds:

                for index,cond in enumerate(["PF.GIF?PIC","FA.GIF?PIC","NG.GIF?PIC","G.GIF?PIC","VB.GIF?PIC","BS.GIF?PIC","BR.GIF?PIC"]): 

                    if cond in main_cond:           

                        product["condition"] += index
        else:
            product["condition"] = 'None'



        product["solf_for"] = response.xpath("//font[@id='CID_RT_Zuschlag0']/parent::td/following-sibling::td/font/text()").extract_first()
        
        if product["solf_for"]:

            product["solf_for"]= product["solf_for"].replace("\xa0€","")
        else:
            product["solf_for"] = "None"


        product["estimate"] = response.xpath("//font[@id='CID_RT_Ausruf0']/parent::td/following-sibling::td/font/text()").extract_first()

        if product["estimate"]:

            product["estimate"]= product["estimate"].replace("\xa0€","")
        else:
            product["estimate"] = "None"

        
        product["description"] = response.css(".TextS2::text").extract()

        if product["description"]:
            product["description"] = " ".join(product["description"])
            product["description"] = product["description"].replace("'","")
        else:
            product["description"] = "None"

        yield product