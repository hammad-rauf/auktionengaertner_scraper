scrapy crawl auktionen -a new=yes
scrapy crawl auktionen -a new=no

same function(backup images and database )

please install selenium ,scrapy , beautifulsoup
